# streamlit_FT
Streamlit app to analyse FT incremental data

Clone the repo and execute the following commands:

`cd streamlit_FT`

`virtualenv .`

`pip install -r requirements.txt`

Once completed, run `streamlit run app.py`


Streamlit Docs: https://docs.streamlit.io/library/api-reference
